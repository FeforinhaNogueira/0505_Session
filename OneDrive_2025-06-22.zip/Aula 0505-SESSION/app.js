const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

//Middleware para processar dados do formulário e JSON
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

//Configurar o middleware de sessão
app.use(session({
    secret: 'chaveSuperSecretaParaLogin', //Mantenha isso em uma variável de ambiente em produção
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 3600000, //1 hora
        httpOnly: true,
        secure: false,
    }
}));

//servir arquivos estaticos (CSS para estilização)
app.use(express.static(path.join(__dirname, 'public')));

//configurar o motor de template (EJS neste exemplo)
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

//Simulação de um banco de dados de usuários (substitua por seu banco de dados real)
const users = [
    { id: 1, username: 'aluno', password: 'Senai1234' }, //Senha 1 hasheada 
    { id: 2, username: 'usuario2', password: 'senha2' }
];

//Middleware para verificar se o usuário está logado 
function requireLogin(req, res, next) {
    if (req.session && req.session.userId) {
        return next();
    } else {
        res.redirect('/login');
    }
}

//Rota para exibir a página de login
app.get('/login', (req, res) => {
    if (req.session.userId) {
        res.render('dashboard', { username: req.session.username });
    }
    else {
        res.render('login');
    }
});

//Rota para processar o envio do formulário de login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const user = users.find(u => u.username === username);

    //console.log('nome de usuario recebido:', username); //Verifique o que está chegando do formulário
    //console.log('Usuário encontrado no array:', user);

    if (user) {
        const passwordMatch = user.password;
        if (passwordMatch) {
            req.session.userId = user.id;
            req.session.username = user.username;
            return res.redirect('/dashboard');
        } else {
            return res.render('login', { error: 'Senha incorreta' });
        }
    } else {
        return res.render('login', { error: 'Usuário não encontrado' });
    }
});

//Rota para exibir a página de dashboard
app.get('/dashboard', requireLogin, (req, res) => {
    res.render('dashboard', { username: req.session.username });
});

//Rota para logout 
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Erro ao destruir a sessão:', err);
            return res.status(500).send('Erro ao fazer logout');
        }
        res.redirect('/login');
    });
});

app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
});

